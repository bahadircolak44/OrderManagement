from unittest import TestCase

from rest_framework.test import APIClient

user_data = {
    "username": "test@test.com",
    "password": "123123",
    "first_name": "test",
    "last_name": "test"
}


class APIClientProxy:
    def __init__(self, client):
        self.client = client

    def check(self, res):
        if res.status_code >= 400 and hasattr(res, 'data'):
            print(res.request['REQUEST_METHOD'], res.request['PATH_INFO'], res.data)

        return res

    def credentials(self, *args, **kwargs):
        return self.client.credentials(*args, **kwargs)

    def get(self, *args, **kwargs):
        return self.check(self.client.get(*args, **kwargs))

    def post(self, *args, **kwargs):
        return self.check(self.client.post(*args, **kwargs))

    def put(self, *args, **kwargs):
        return self.check(self.client.put(*args, **kwargs))

    def delete(self, *args, **kwargs):
        return self.check(self.client.delete(*args, **kwargs))


class LoggedInTestCase(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.client = APIClientProxy(self.client)
        print("+++TEST++++")